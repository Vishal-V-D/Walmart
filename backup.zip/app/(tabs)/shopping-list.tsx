import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Plus, Trash2, Navigation, Check, X, Filter, ScanLine, Mic, Star } from 'lucide-react-native';
import { useTheme } from '@/hooks/useTheme';

interface Product {
  id: string;
  name: string;
  aisle: string;
  shelf: string;
  price: number;
  category: string;
  image?: string;
  rating?: number;
  inStock: boolean;
}

interface ShoppingListItem {
  id: string;
  product: Product;
  quantity: number;
  found: boolean;
  priority: 'low' | 'medium' | 'high';
}

export default function ShoppingListScreen() {
  const { colors } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [shoppingList, setShoppingList] = useState<ShoppingListItem[]>([]);
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [filter, setFilter] = useState<'all' | 'found' | 'pending'>('all');

  const sampleProducts: Product[] = [
    { 
      id: '1', 
      name: 'Organic 2% Milk', 
      aisle: 'A12', 
      shelf: 'B2', 
      price: 4.98, 
      category: 'Dairy',
      image: 'https://images.pexels.com/photos/236010/pexels-photo-236010.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      rating: 4.5,
      inStock: true
    },
    { 
      id: '2', 
      name: 'Artisan Sourdough Bread', 
      aisle: 'A8', 
      shelf: 'C1', 
      price: 3.48, 
      category: 'Bakery',
      image: 'https://images.pexels.com/photos/209206/pexels-photo-209206.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      rating: 4.8,
      inStock: true
    },
    { 
      id: '3', 
      name: 'Fresh Organic Bananas', 
      aisle: 'A15', 
      shelf: 'D3', 
      price: 1.98, 
      category: 'Produce',
      image: 'https://images.pexels.com/photos/61127/pexels-photo-61127.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      rating: 4.3,
      inStock: true
    },
    { 
      id: '4', 
      name: 'Free-Range Chicken Breast', 
      aisle: 'A6', 
      shelf: 'A4', 
      price: 12.97, 
      category: 'Meat',
      image: 'https://images.pexels.com/photos/616354/pexels-photo-616354.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      rating: 4.6,
      inStock: true
    },
    { 
      id: '5', 
      name: 'Farm Fresh Large Eggs', 
      aisle: 'A12', 
      shelf: 'B1', 
      price: 3.98, 
      category: 'Dairy',
      image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      rating: 4.7,
      inStock: true
    },
    { 
      id: '6', 
      name: 'Organic Gala Apples', 
      aisle: 'A15', 
      shelf: 'D1', 
      price: 5.98, 
      category: 'Produce',
      image: 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
      rating: 4.4,
      inStock: true
    },
  ];

  useEffect(() => {
    if (searchQuery.length > 0) {
      setIsSearching(true);
      const results = sampleProducts.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setSearchResults(results);
      setIsSearching(false);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery]);

  const addToList = (product: Product, priority: 'low' | 'medium' | 'high' = 'medium') => {
    const existingItem = shoppingList.find(item => item.product.id === product.id);
    if (existingItem) {
      setShoppingList(prevList =>
        prevList.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      const newItem: ShoppingListItem = {
        id: Date.now().toString(),
        product,
        quantity: 1,
        found: false,
        priority,
      };
      setShoppingList(prevList => [...prevList, newItem]);
    }
    setSearchQuery('');
  };

  const removeFromList = (itemId: string) => {
    setShoppingList(prevList => prevList.filter(item => item.id !== itemId));
  };

  const toggleFound = (itemId: string) => {
    setShoppingList(prevList =>
      prevList.map(item =>
        item.id === itemId ? { ...item, found: !item.found } : item
      )
    );
  };

  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromList(itemId);
      return;
    }
    setShoppingList(prevList =>
      prevList.map(item =>
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const startNavigation = () => {
    if (shoppingList.length === 0) {
      Alert.alert('Empty List', 'Please add items to your shopping list first.');
      return;
    }
    
    const pendingItems = shoppingList.filter(item => !item.found);
    if (pendingItems.length === 0) {
      Alert.alert('All Items Found', 'You\'ve found all items on your list!');
      return;
    }

    Alert.alert(
      'Smart Navigation Started',
      `Starting optimized navigation for ${pendingItems.length} remaining items.\n\nFirst stop: ${pendingItems[0].product.aisle} - ${pendingItems[0].product.name}`,
      [{ text: 'Let\'s Go!', onPress: () => {} }]
    );
  };

  const filteredList = shoppingList.filter(item => {
    switch (filter) {
      case 'found':
        return item.found;
      case 'pending':
        return !item.found;
      default:
        return true;
    }
  });

  const totalItems = shoppingList.reduce((sum, item) => sum + item.quantity, 0);
  const foundItems = shoppingList.filter(item => item.found).length;
  const totalValue = shoppingList.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return colors.error;
      case 'medium':
        return colors.accent;
      default:
        return colors.textTertiary;
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.surface,
    },
    header: {
      padding: 24,
      backgroundColor: colors.background,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTop: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 8,
    },
    title: {
      fontSize: 28,
      fontWeight: '800',
      color: colors.text,
      fontFamily: 'Inter-ExtraBold',
    },
    subtitle: {
      fontSize: 16,
      color: colors.textSecondary,
      marginTop: 4,
      fontFamily: 'Inter-Regular',
    },
    headerActions: {
      flexDirection: 'row',
      gap: 8,
    },
    headerButton: {
      backgroundColor: colors.surface,
      padding: 8,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: colors.border,
    },
    statsContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginTop: 16,
      paddingTop: 16,
      borderTopWidth: 1,
      borderTopColor: colors.border,
    },
    statItem: {
      alignItems: 'center',
    },
    statValue: {
      fontSize: 18,
      fontWeight: '800',
      color: colors.text,
      fontFamily: 'Inter-ExtraBold',
    },
    statLabel: {
      fontSize: 12,
      color: colors.textSecondary,
      marginTop: 4,
      fontFamily: 'Inter-SemiBold',
    },
    searchContainer: {
      padding: 20,
      backgroundColor: colors.background,
    },
    searchBox: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderRadius: 16,
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderWidth: 1,
      borderColor: colors.border,
    },
    searchInput: {
      flex: 1,
      marginLeft: 12,
      fontSize: 16,
      color: colors.text,
      fontFamily: 'Inter-Regular',
    },
    searchActions: {
      flexDirection: 'row',
      gap: 8,
      marginLeft: 8,
    },
    searchActionButton: {
      backgroundColor: colors.primary,
      padding: 8,
      borderRadius: 8,
    },
    content: {
      flex: 1,
    },
    filterContainer: {
      flexDirection: 'row',
      paddingHorizontal: 20,
      paddingVertical: 12,
      backgroundColor: colors.background,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    filterButton: {
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderRadius: 20,
      marginRight: 12,
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
    },
    filterButtonActive: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    filterButtonText: {
      fontSize: 14,
      fontWeight: '600',
      color: colors.text,
      fontFamily: 'Inter-SemiBold',
    },
    filterButtonTextActive: {
      color: colors.white,
    },
    searchResults: {
      padding: 20,
    },
    sectionTitle: {
      fontSize: 20,
      fontWeight: '700',
      color: colors.text,
      marginBottom: 16,
      fontFamily: 'Inter-Bold',
    },
    searchResultCard: {
      backgroundColor: colors.background,
      padding: 16,
      borderRadius: 16,
      marginBottom: 12,
      flexDirection: 'row',
      alignItems: 'center',
      shadowColor: colors.shadow,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.08,
      shadowRadius: 8,
      elevation: 3,
      borderWidth: 1,
      borderColor: colors.border,
    },
    productImage: {
      width: 60,
      height: 60,
      borderRadius: 12,
      marginRight: 16,
    },
    searchResultInfo: {
      flex: 1,
    },
    searchResultName: {
      fontSize: 16,
      fontWeight: '700',
      color: colors.text,
      fontFamily: 'Inter-Bold',
    },
    searchResultDetails: {
      fontSize: 14,
      color: colors.textSecondary,
      marginTop: 4,
      fontFamily: 'Inter-Regular',
    },
    searchResultPrice: {
      fontSize: 16,
      fontWeight: '800',
      color: colors.secondary,
      marginTop: 4,
      fontFamily: 'Inter-ExtraBold',
    },
    ratingContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 4,
    },
    rating: {
      fontSize: 12,
      color: colors.textSecondary,
      marginLeft: 4,
      fontFamily: 'Inter-SemiBold',
    },
    addButton: {
      backgroundColor: colors.primary,
      padding: 12,
      borderRadius: 12,
    },
    shoppingListContainer: {
      padding: 20,
    },
    listHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16,
    },
    navigateButton: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.primary,
      paddingHorizontal: 20,
      paddingVertical: 12,
      borderRadius: 12,
    },
    navigateButtonText: {
      color: colors.white,
      fontWeight: '700',
      marginLeft: 8,
      fontFamily: 'Inter-Bold',
    },
    listItem: {
      backgroundColor: colors.background,
      padding: 16,
      borderRadius: 16,
      marginBottom: 12,
      flexDirection: 'row',
      alignItems: 'center',
      shadowColor: colors.shadow,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.08,
      shadowRadius: 8,
      elevation: 3,
      borderWidth: 1,
      borderColor: colors.border,
    },
    listItemFound: {
      backgroundColor: colors.surface,
      borderColor: colors.secondary,
      opacity: 0.8,
    },
    checkButton: {
      marginRight: 16,
    },
    uncheckedCircle: {
      width: 24,
      height: 24,
      borderRadius: 12,
      borderWidth: 2,
      borderColor: colors.border,
    },
    checkedCircle: {
      width: 24,
      height: 24,
      borderRadius: 12,
      backgroundColor: colors.secondary,
      justifyContent: 'center',
      alignItems: 'center',
    },
    itemImage: {
      width: 50,
      height: 50,
      borderRadius: 8,
      marginRight: 12,
    },
    itemInfo: {
      flex: 1,
    },
    itemName: {
      fontSize: 16,
      fontWeight: '700',
      color: colors.text,
      fontFamily: 'Inter-Bold',
    },
    itemNameFound: {
      textDecorationLine: 'line-through',
      color: colors.textSecondary,
    },
    itemDetails: {
      fontSize: 14,
      color: colors.textSecondary,
      marginTop: 4,
      fontFamily: 'Inter-Regular',
    },
    itemPrice: {
      fontSize: 16,
      fontWeight: '800',
      color: colors.secondary,
      marginTop: 4,
      fontFamily: 'Inter-ExtraBold',
    },
    itemActions: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },
    quantityContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: colors.border,
    },
    quantityButton: {
      padding: 8,
    },
    quantityText: {
      fontSize: 16,
      fontWeight: '700',
      color: colors.text,
      paddingHorizontal: 12,
      fontFamily: 'Inter-Bold',
    },
    removeButton: {
      backgroundColor: colors.error,
      padding: 8,
      borderRadius: 8,
    },
    priorityIndicator: {
      width: 4,
      height: '100%',
      position: 'absolute',
      left: 0,
      top: 0,
      borderTopLeftRadius: 16,
      borderBottomLeftRadius: 16,
    },
    emptyState: {
      alignItems: 'center',
      padding: 40,
    },
    emptyStateTitle: {
      fontSize: 20,
      fontWeight: '700',
      color: colors.text,
      marginBottom: 8,
      fontFamily: 'Inter-Bold',
    },
    emptyStateDescription: {
      fontSize: 16,
      color: colors.textSecondary,
      textAlign: 'center',
      lineHeight: 24,
      fontFamily: 'Inter-Regular',
    },
  });

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.title}>Shopping List</Text>
            <Text style={styles.subtitle}>Smart shopping made easy</Text>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.headerButton}>
              <ScanLine size={20} color={colors.text} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.headerButton}>
              <Filter size={20} color={colors.text} />
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{totalItems}</Text>
            <Text style={styles.statLabel}>Total Items</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{foundItems}</Text>
            <Text style={styles.statLabel}>Found</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>${totalValue.toFixed(2)}</Text>
            <Text style={styles.statLabel}>Est. Total</Text>
          </View>
        </View>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Search size={20} color={colors.textSecondary} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search products..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor={colors.textTertiary}
          />
          <View style={styles.searchActions}>
            <TouchableOpacity style={styles.searchActionButton}>
              <Mic size={16} color={colors.white} />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <View style={styles.filterContainer}>
        {['all', 'pending', 'found'].map((filterOption) => (
          <TouchableOpacity
            key={filterOption}
            style={[
              styles.filterButton,
              filter === filterOption && styles.filterButtonActive,
            ]}
            onPress={() => setFilter(filterOption as any)}>
            <Text style={[
              styles.filterButtonText,
              filter === filterOption && styles.filterButtonTextActive,
            ]}>
              {filterOption.charAt(0).toUpperCase() + filterOption.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {searchQuery.length > 0 && (
          <View style={styles.searchResults}>
            <Text style={styles.sectionTitle}>Search Results</Text>
            {searchResults.map((product) => (
              <TouchableOpacity
                key={product.id}
                style={styles.searchResultCard}
                onPress={() => addToList(product)}>
                <Image source={{ uri: product.image }} style={styles.productImage} />
                <View style={styles.searchResultInfo}>
                  <Text style={styles.searchResultName}>{product.name}</Text>
                  <Text style={styles.searchResultDetails}>
                    {product.category} • Aisle {product.aisle}, Shelf {product.shelf}
                  </Text>
                  <View style={styles.ratingContainer}>
                    <Star size={12} color={colors.accent} fill={colors.accent} />
                    <Text style={styles.rating}>{product.rating}</Text>
                  </View>
                  <Text style={styles.searchResultPrice}>${product.price}</Text>
                </View>
                <TouchableOpacity style={styles.addButton}>
                  <Plus size={20} color={colors.white} />
                </TouchableOpacity>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {filteredList.length > 0 && (
          <View style={styles.shoppingListContainer}>
            <View style={styles.listHeader}>
              <Text style={styles.sectionTitle}>Your Shopping List</Text>
              <TouchableOpacity
                style={styles.navigateButton}
                onPress={startNavigation}>
                <Navigation size={20} color={colors.white} />
                <Text style={styles.navigateButtonText}>Navigate</Text>
              </TouchableOpacity>
            </View>

            {filteredList.map((item) => (
              <View key={item.id} style={[
                styles.listItem,
                item.found && styles.listItemFound
              ]}>
                <View 
                  style={[
                    styles.priorityIndicator, 
                    { backgroundColor: getPriorityColor(item.priority) }
                  ]} 
                />
                
                <TouchableOpacity
                  style={styles.checkButton}
                  onPress={() => toggleFound(item.id)}>
                  {item.found ? (
                    <View style={styles.checkedCircle}>
                      <Check size={16} color={colors.white} />
                    </View>
                  ) : (
                    <View style={styles.uncheckedCircle} />
                  )}
                </TouchableOpacity>
                
                <Image source={{ uri: item.product.image }} style={styles.itemImage} />
                
                <View style={styles.itemInfo}>
                  <Text style={[
                    styles.itemName,
                    item.found && styles.itemNameFound
                  ]}>
                    {item.product.name}
                  </Text>
                  <Text style={styles.itemDetails}>
                    Aisle {item.product.aisle}, Shelf {item.product.shelf}
                  </Text>
                  <Text style={styles.itemPrice}>${(item.product.price * item.quantity).toFixed(2)}</Text>
                </View>
                
                <View style={styles.itemActions}>
                  <View style={styles.quantityContainer}>
                    <TouchableOpacity 
                      style={styles.quantityButton}
                      onPress={() => updateQuantity(item.id, item.quantity - 1)}>
                      <Text style={styles.quantityText}>-</Text>
                    </TouchableOpacity>
                    <Text style={styles.quantityText}>{item.quantity}</Text>
                    <TouchableOpacity 
                      style={styles.quantityButton}
                      onPress={() => updateQuantity(item.id, item.quantity + 1)}>
                      <Text style={styles.quantityText}>+</Text>
                    </TouchableOpacity>
                  </View>
                  
                  <TouchableOpacity
                    style={styles.removeButton}
                    onPress={() => removeFromList(item.id)}>
                    <Trash2 size={16} color={colors.white} />
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        )}

        {filteredList.length === 0 && searchQuery.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateTitle}>Start Building Your List</Text>
            <Text style={styles.emptyStateDescription}>
              Search for products and add them to your shopping list. We'll help you navigate to find them quickly with smart routing and real-time updates.
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}