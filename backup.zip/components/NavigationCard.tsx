// components/NavigationCard.tsx
import React, { useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Navigation, XCircle, Eye, ArrowUp, ArrowDown, ArrowRight } from 'lucide-react-native';
import { useTheme } from '@/hooks/useTheme';

// Removed NavigationStep interface from here as it's defined in map.tsx and not directly used as a prop here.
// Instead, its properties are passed individually.

interface NavigationCardProps {
  currentInstruction: string;
  nextStepInstruction: string;
  destination: string;
  distanceRemaining: string;
  estimatedTimeRemaining: number;
  onStopNavigation: () => void;
  direction?: 'straight' | 'left' | 'right' | 'up' | 'down';
  currentFloor: number;
  nextFloor?: number;
  isARActive: boolean;
  onToggleAR: () => void;
  accessibilityMode: boolean;
}

export function NavigationCard({
  currentInstruction,
  nextStepInstruction,
  destination,
  distanceRemaining,
  estimatedTimeRemaining,
  onStopNavigation,
  direction,
  currentFloor,
  nextFloor,
  isARActive,
  onToggleAR,
  accessibilityMode, // Still not used, but kept as per previous request
}: NavigationCardProps) {
  const { colors } = useTheme();

  const getDirectionIcon = (dir?: 'straight' | 'left' | 'right' | 'up' | 'down') => {
    switch (dir) {
      case 'up': return <ArrowUp size={20} color={colors.white} />;
      case 'down': return <ArrowDown size={20} color={colors.white} />;
      case 'left': return <ArrowRight size={20} color={colors.white} style={{ transform: [{ rotate: '-90deg' }] }} />;
      case 'right': return <ArrowRight size={20} color={colors.white} style={{ transform: [{ rotate: '90deg' }] }} />;
      default: return <ArrowRight size={20} color={colors.white} />;
    }
  };

  const styles = useMemo(() => StyleSheet.create({
    card: {
      backgroundColor: colors.card,
      borderRadius: 16,
      marginHorizontal: 20,
      marginTop: 20,
      padding: 15,
      shadowColor: colors.shadow,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.15,
      shadowRadius: 10,
      elevation: 6,
      alignItems: 'center',
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },
    headerText: {
      fontSize: 18,
      fontWeight: 'bold',
      color: colors.text,
      marginLeft: 10,
    },
    instructionText: {
      fontSize: 16,
      color: colors.textSecondary,
      textAlign: 'center',
      marginBottom: 10,
    },
    locationText: {
      fontSize: 14,
      color: colors.textSecondary,
      marginBottom: 5,
    },
    timeDistanceText: {
      fontSize: 14,
      color: colors.textSecondary,
      marginBottom: 15,
    },
    controls: {
      flexDirection: 'row',
      marginTop: 10,
      width: '100%',
      justifyContent: 'space-around',
    },
    button: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 10,
      paddingHorizontal: 15,
      borderRadius: 25,
      backgroundColor: colors.primary,
      shadowColor: colors.shadow,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 3,
      elevation: 2,
    },
    stopButton: {
      backgroundColor: colors.error,
    },
    arButton: {
      backgroundColor: colors.secondary,
    },
    buttonText: {
      color: colors.white,
      marginLeft: 8,
      fontWeight: '600',
    },
    stepCounter: {
      marginTop: 10,
      fontSize: 12,
      color: colors.textTertiary,
    },
    directionIconContainer: {
      backgroundColor: colors.primaryDark,
      borderRadius: 25,
      padding: 8,
      marginRight: 10,
    },
  }), [colors]);

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        {direction && (
          <View style={styles.directionIconContainer}>
            {getDirectionIcon(direction)}
          </View>
        )}
        <Text style={styles.headerText}>Navigation</Text>
      </View>
      <Text style={styles.instructionText}>
        {currentInstruction}
      </Text>
      <Text style={styles.locationText}>
        Next: {destination} {nextFloor ? `(Floor ${nextFloor})` : ''}
      </Text>
      <Text style={styles.timeDistanceText}>
        Est. Time: {Math.ceil(estimatedTimeRemaining / 60)} min
        {distanceRemaining && ` | Distance: ${distanceRemaining}`}
      </Text>
      {/* Removed totalSteps and currentStepIndex as they are not directly passed as props anymore,
          and the instruction/location are already available.
          If needed, you can re-add them to NavigationCardProps and pass from map.tsx. */}
      {/* <Text style={styles.stepCounter}>
        Step {currentStepIndex + 1} of {totalSteps}
      </Text> */}

      <View style={styles.controls}>
        <TouchableOpacity style={[styles.button, styles.arButton]} onPress={onToggleAR}>
          <Eye size={20} color={colors.white} />
          <Text style={styles.buttonText}>{isARActive ? 'Exit AR' : 'Start AR'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.stopButton]} onPress={onStopNavigation}>
          <XCircle size={20} color={colors.white} />
          <Text style={styles.buttonText}>Stop</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}